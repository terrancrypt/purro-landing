import{c as M,r as g,x as T,j as e,y as I,g as W,e as _,f as L,R as O,B as f,b as X,z as K,X as q,C as k}from"./seed-phrase-render.js";import{h as $,e as B,b as Y,a as H}from"./ethereum-eth-logo.js";import{T as U}from"./triangle-alert.js";import{W as G}from"./index2.js";/**
 * @license lucide-react v0.513.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],de=M("key-round",J),Z=({onSeedPhraseChange:s,onValidationChange:a,className:t="",wordCount:r=12})=>{const[i,y]=g.useState(Array(r).fill("")),[m,v]=g.useState({isValid:!1,message:"",type:"error"}),[b,p]=g.useState(!1),c=g.useRef([]),{checkSeedPhraseExists:u}=T(),S=async(o,l)=>{const n=[...i];n[o]=l.trim().toLowerCase(),y(n),!b&&l.trim()&&p(!0);const d=n.join(" ").trim();let x=I(d,r);if(x.isValid&&d.trim())try{await u(d)&&(x={isValid:!1,message:"This seed phrase is already imported",type:"warning"})}catch(j){console.error("Error checking seed phrase existence:",j)}v(x),s(d),a?.(x.isValid),l.trim()&&o<r-1&&c.current[o+1]?.focus()},E=(o,l)=>{l.key==="Backspace"&&!i[o]&&o>0?c.current[o-1]?.focus():l.key==="Enter"&&o<r-1?c.current[o+1]?.focus():l.key===" "&&o<r-1&&(l.preventDefault(),c.current[o+1]?.focus())},h=async o=>{o.preventDefault();const n=o.clipboardData.getData("text").trim().split(/\s+/).slice(0,r);!b&&n.length>0&&p(!0);const d=Array(r).fill("");n.forEach((w,A)=>{A<r&&(d[A]=w.toLowerCase())}),y(d);const x=d.join(" ").trim();let j=I(x,r);if(j.isValid&&x.trim())try{await u(x)&&(j={isValid:!1,message:"This seed phrase is already imported",type:"warning"})}catch(w){console.error("Error checking seed phrase existence:",w)}v(j),s(x),a?.(j.isValid);const z=d.findIndex(w=>!w),F=z!==-1?z:Math.min(n.length,r-1);c.current[F]?.focus()};g.useEffect(()=>{(async()=>{const n=i.join(" ").trim();let d=I(n,r);if(d.isValid&&n.trim())try{await u(n)&&(d={isValid:!1,message:"This seed phrase is already imported",type:"warning"})}catch(x){console.error("Error checking seed phrase existence:",x)}v(d),a?.(d.isValid)})(),i.some(n=>n.trim())||p(!1)},[r,i,a,u]);const N=()=>{switch(m.type){case"success":return e.jsx(_,{className:"size-4 text-green-400"});case"warning":return e.jsx(U,{className:"size-4 text-yellow-400"});case"error":default:return e.jsx(W,{className:"size-4 text-red-400"})}},P=()=>{switch(m.type){case"success":return"text-green-400";case"warning":return"text-yellow-400";case"error":default:return"text-red-400"}},D=b&&m.message;return e.jsxs("div",{className:`flex flex-col gap-4 ${t}`,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3",children:Array.from({length:r},(o,l)=>e.jsxs("div",{className:"flex items-center gap-2 p-3 bg-[var(--card-color)] border border-white/10 rounded-lg focus-within:border-[var(--primary-color-light)] min-w-0",children:[e.jsx("span",{className:"text-xs text-gray-400 min-w-[20px]",children:l+1}),e.jsx("input",{ref:n=>{c.current[l]=n},type:"text",value:i[l],onChange:n=>S(l,n.target.value),onKeyDown:n=>E(l,n),onPaste:h,placeholder:"word",className:"flex-1 bg-transparent text-sm font-medium text-white placeholder-gray-500 outline-none min-w-0 w-full",autoComplete:"off",spellCheck:!1})]},l))}),D&&e.jsxs("div",{className:"flex items-center gap-2 text-sm",children:[N(),e.jsx("span",{className:P(),children:m.message})]})]})},Q="/purro.gif",pe=({className:s="",children:a})=>{const t={universeContainer:{position:"absolute",top:0,left:0,width:"100%",height:"100%",overflow:"hidden",background:"var(--background-color)"},universeBg:{position:"absolute",top:0,left:0,width:"100%",height:"100%",background:`
        radial-gradient(ellipse at center, 
          var(--primary-color-dark) 0%, 
          var(--background-color) 40%, 
          #000 100%
        )
      `,zIndex:1},stars:{position:"absolute",top:0,left:0,width:"100%",height:"100%",zIndex:2},nebula:{position:"absolute",borderRadius:"50%",filter:"blur(40px)",zIndex:2},shootingStar:{position:"absolute",width:"2px",height:"2px",background:"var(--primary-color-light)",borderRadius:"50%",zIndex:3},planet:{position:"absolute",borderRadius:"50%",zIndex:2},universeContent:{position:"relative",zIndex:10,width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center"}};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px) scale(1); }
          33% { transform: translateY(-20px) translateX(10px) scale(1.1); }
          66% { transform: translateY(10px) translateX(-15px) scale(0.9); }
        }
        
        @keyframes shoot {
          0% {
            transform: translateX(0) translateY(0);
            opacity: 1;
          }
          10% {
            opacity: 1;
          }
          100% {
            transform: translateX(calc(100vw + 100px)) translateY(-200px);
            opacity: 0;
          }
        }
        
        @keyframes orbit {
          0% { transform: rotate(0deg) translateX(50px) rotate(0deg); }
          100% { transform: rotate(360deg) translateX(50px) rotate(-360deg); }
        }
        
        .universe-stars-small {
          background-image: 
            radial-gradient(2px 2px at 20px 30px, var(--primary-color-light), transparent),
            radial-gradient(2px 2px at 40px 70px, var(--text-color), transparent),
            radial-gradient(1px 1px at 90px 40px, var(--primary-color-light), transparent),
            radial-gradient(1px 1px at 130px 80px, rgba(240,240,240,0.6), transparent),
            radial-gradient(2px 2px at 160px 30px, var(--text-color), transparent);
          background-repeat: repeat;
          background-size: 200px 100px;
          animation: twinkle 4s infinite;
        }
        
        .universe-stars-medium {
          background-image: 
            radial-gradient(3px 3px at 30px 50px, var(--primary-color-light), transparent),
            radial-gradient(2px 2px at 80px 20px, var(--text-color), transparent),
            radial-gradient(3px 3px at 120px 90px, rgba(143,255,253,0.7), transparent);
          background-repeat: repeat;
          background-size: 300px 150px;
          animation: twinkle 6s infinite reverse;
        }
        
        .universe-stars-large {
          background-image: 
            radial-gradient(4px 4px at 50px 60px, var(--primary-color-light), transparent),
            radial-gradient(3px 3px at 150px 40px, var(--text-color), transparent);
          background-repeat: repeat;
          background-size: 400px 200px;
          animation: twinkle 8s infinite;
        }
        
        .universe-nebula-1 {
          width: 300px;
          height: 200px;
          background: radial-gradient(circle, 
            rgba(8, 139, 136, 0.3) 0%, 
            rgba(22, 98, 96, 0.2) 50%, 
            transparent 70%
          );
          top: 20%;
          left: 10%;
          animation: float 20s infinite ease-in-out;
        }
        
        .universe-nebula-2 {
          width: 250px;
          height: 180px;
          background: radial-gradient(circle, 
            rgba(143, 255, 253, 0.2) 0%, 
            rgba(8, 139, 136, 0.15) 50%, 
            transparent 70%
          );
          top: 60%;
          right: 15%;
          animation: float 20s infinite ease-in-out;
          animation-delay: -7s;
        }
        
        .universe-nebula-3 {
          width: 200px;
          height: 150px;
          background: radial-gradient(circle, 
            rgba(22, 55, 55, 0.4) 0%, 
            rgba(8, 139, 136, 0.2) 50%, 
            transparent 70%
          );
          bottom: 30%;
          left: 60%;
          animation: float 20s infinite ease-in-out;
          animation-delay: -14s;
        }
        
        .universe-shooting-star-1 {
          top: 20%;
          left: -100px;
          animation: shoot 3s infinite linear;
          animation-delay: 1s;
        }
        
        .universe-shooting-star-2 {
          top: 50%;
          left: -100px;
          animation: shoot 4s infinite linear;
          animation-delay: 3s;
        }
        
        .universe-shooting-star-3 {
          top: 80%;
          left: -100px;
          animation: shoot 5s infinite linear;
          animation-delay: 6s;
        }
        
        .universe-planet-1 {
          width: 60px;
          height: 60px;
          background: radial-gradient(circle at 30% 30%, 
            var(--primary-color), 
            var(--primary-color-dark), 
            var(--card-color)
          );
          top: 15%;
          right: 20%;
          box-shadow: 0 0 20px rgba(8, 139, 136, 0.5);
          animation: orbit 40s infinite linear;
        }
        
        .universe-planet-2 {
          width: 40px;
          height: 40px;
         background: radial-gradient(circle at 50% 40%, 
            #4DA2FF 0%,
            #3d88e6 30%,
            #2d6ecc 60%,
            #1d54b3 80%,
            #0d3a99 100%
            );
          bottom: 25%;
          left: 15%;
          box-shadow: 0 0 15px rgba(77, 162, 255, 0.4);
          animation: orbit 60s infinite linear reverse;
        }
        
        .universe-planet-3 {
          width: 40px;
          height: 40px;
          background: radial-gradient(circle at 50% 40%, 
            #4a4a6a 0%,
            #3a3a5a 20%,
            #2a2a4a 40%,
            #1a1a3a 60%,
            #0a0a2a 80%,
            #000000 100%
            );
          top: 70%;
          right: 20%;
          box-shadow: 0 0 10px rgba(22, 55, 55, 0.3);
          animation: orbit 80s infinite linear;
        }

        .universe-planet-4 {
          width: 40px;
          height: 40px;
          background: radial-gradient(circle at 50% 40%, 
            #e6f3ff 0%,
            #b8d4ff 20%,
            #8fb3ff 40%,
            #7b94ff 60%,
            #6c7aff 80%,
            #5d5fff 100%
            );
          top: 30%;
          left: 10%;
          box-shadow: 0 0 10px rgba(22, 55, 55, 0.3);
          animation: orbit 80s infinite linear;
        }

        .purro-animate {
          width: 200px;
          height: 200px;
          animation: float 25s infinite ease-in-out;
          top: 40%;
          left: 20%;
          transform: translate(0, -50%);
          z-index: 5;
        }

        @media (max-width: 768px) {
          .universe-nebula-1, .universe-nebula-2, .universe-nebula-3 {
            width: 150px !important;
            height: 100px !important;
          }
          
          .universe-planet-1 {
            width: 40px !important;
            height: 40px !important;
          }
          
          .universe-planet-2 {
            width: 30px !important;
            height: 30px !important;
          }
          
          .universe-planet-3 {
            width: 30px !important;
            height: 30px !important;
          }

          .purro-animate {
            width: 120px !important;
            height: 120px !important;
            top: 30% !important;
            right: 5% !important;
          }
        }
      `}),e.jsxs("div",{className:`${s}`,style:t.universeContainer,children:[e.jsx("div",{style:t.universeBg}),e.jsx("div",{className:"universe-stars-small",style:t.stars}),e.jsx("div",{className:"universe-stars-medium",style:t.stars}),e.jsx("div",{className:"universe-stars-large",style:t.stars}),e.jsx("div",{className:"universe-nebula-1",style:t.nebula}),e.jsx("div",{className:"universe-nebula-2",style:t.nebula}),e.jsx("div",{className:"universe-nebula-3",style:t.nebula}),e.jsx("div",{className:"universe-shooting-star-1",style:t.shootingStar}),e.jsx("div",{className:"universe-shooting-star-2",style:t.shootingStar}),e.jsx("div",{className:"universe-shooting-star-3",style:t.shootingStar}),e.jsx("div",{className:"universe-planet-1 flex items-center justify-center object-contain",style:t.planet,children:e.jsx("img",{src:$,alt:"logo",className:"size-10"})}),e.jsx("div",{className:"universe-planet-2 flex items-center justify-center object-contain",style:t.planet}),e.jsx("div",{className:"universe-planet-3 flex items-center justify-center object-contain",style:t.planet}),e.jsx("div",{className:"universe-planet-4 flex items-center justify-center object-contain",style:t.planet}),e.jsx("div",{className:"purro-animate flex items-center justify-center object-contain",style:t.planet,children:e.jsx("img",{src:Q,alt:"purro animated",className:"w-full h-full object-contain"})}),a&&e.jsx("div",{style:t.universeContent,children:a})]})]})},xe=()=>e.jsx("div",{className:"flex flex-col items-center justify-center size-full",children:e.jsxs("div",{className:"flex-1 size-full flex flex-col items-center justify-center gap-2",children:[e.jsx("div",{className:"flex items-center justify-center size-18 bg-red-500 rounded-full",children:e.jsx(W,{className:"size-10 text-red-100"})}),e.jsx("h1",{className:"text-2xl font-bold",children:"Some thing went wrong"}),e.jsx("p",{className:"text-lg text-gray-500",children:"Please try again later or contact support."})]})}),C=L(s=>({mnemonic:void 0,password:void 0,confirmPassword:void 0,privateKey:void 0,address:void 0,chain:void 0,selectedSeedPhraseId:void 0,importType:null,setMnemonic:a=>{s({mnemonic:a})},setPassword:a=>s({password:a}),setConfirmPassword:a=>s({confirmPassword:a}),setPrivateKey:a=>s({privateKey:a}),setAddress:a=>s({address:a}),setChain:a=>s({chain:a}),setAccountName:a=>s({accountName:a}),setSelectedSeedPhraseId:a=>s({selectedSeedPhraseId:a}),setImportType:a=>s({importType:a}),reset:()=>s({mnemonic:void 0,password:void 0,confirmPassword:void 0,privateKey:void 0,address:void 0,chain:void 0,accountName:void 0,selectedSeedPhraseId:void 0,importType:null})})),me=({steps:s,currentStep:a})=>{const t=s.findIndex(r=>r===a);return e.jsx("div",{className:"flex-1 flex items-center justify-center space-x-2",children:s.map((r,i)=>e.jsxs(O.Fragment,{children:[e.jsx("div",{className:`w-3 h-3 rounded-full ${i<=t?"bg-[var(--primary-color-light)]":"bg-[var(--card-color)]"}`}),i<s.length-1&&e.jsx("div",{className:`w-8 h-0.5 ${i<t?"bg-[var(--primary-color-light)]":"bg-[var(--card-color)]"}`})]},r))})},ue=({onNext:s})=>{const[a,t]=g.useState(12),[r,i]=g.useState(!1),{mnemonic:y,setMnemonic:m}=C(),v=c=>{m(c)},b=c=>{i(c)},p=c=>{t(c),m(""),i(!1)};return e.jsxs("div",{className:"flex flex-col items-center justify-center size-full p-4",children:[e.jsxs("div",{className:"flex-1 size-full gap-4 space-y-4 overflow-y-auto",children:[e.jsx("div",{className:"space-y-1",children:e.jsx("h1",{className:"text-xl font-bold text-center",children:"Enter your Recovery Phrase"})}),e.jsx("div",{className:"flex justify-center",children:e.jsxs("div",{className:"flex bg-[var(--card-color)] rounded-lg p-1 border border-white/10",children:[e.jsx(f,{onClick:()=>p(12),className:`px-4 py-2 text-sm rounded-md transition-all ${a===12?"bg-[var(--primary-color)] text-white hover:bg-[var(--primary-color)]/80":"bg-transparent text-gray-400 hover:text-white hover:bg-white/10"}`,children:"12 words"}),e.jsx(f,{onClick:()=>p(24),className:`px-4 py-2 text-sm rounded-md transition-all ${a===24?"bg-[var(--primary-color)] text-white hover:bg-[var(--primary-color)]/80":"bg-transparent text-gray-400 hover:text-white hover:bg-white/10"}`,children:"24 words"})]})}),e.jsx("div",{className:"flex-1 w-full max-w-2xl",children:e.jsx(Z,{onSeedPhraseChange:v,onValidationChange:b,wordCount:a},a)})]}),e.jsx("div",{className:"w-full pt-2",children:e.jsx(f,{className:"w-full",disabled:!y||!r,onClick:()=>{s()},children:"Import"})})]})},ee={EVM_CHAINS:["ethereum","hyperevm","base","arbitrum"],ERROR_MESSAGES:{INVALID_PRIVATE_KEY:"Invalid private key. Please try again.",ALREADY_IMPORTED:"This private key is already imported."}},V=(s,a)=>{if(!s.trim()||!a)return{isValid:!1,address:""};try{return ee.EVM_CHAINS.includes(a)?ae(s):a==="solana"?se(s):a==="sui"?te(s):{isValid:!1,address:""}}catch(t){return console.error("Private key validation error:",t),{isValid:!1,address:""}}},ae=s=>{try{let a=s;if(s.startsWith("0x")&&(a=s.slice(2)),!/^[0-9a-fA-F]{64}$/.test(a))return{isValid:!1,address:""};const t=new G(s),r=t.address,i=t.signingKey.publicKey;return r&&r.length>0&&i&&i.length>0?{isValid:!0,address:r}:{isValid:!1,address:""}}catch{return{isValid:!1,address:""}}},se=s=>{try{if(s.startsWith("[")&&s.endsWith("]")){const a=JSON.parse(s);if(Array.isArray(a)&&a.length===64)return{isValid:!0,address:"Solana address validation requires full backend utilities"}}else if(s.startsWith("0x")){const a=s.slice(2);if(/^[0-9a-fA-F]{128}$/.test(a))return{isValid:!0,address:"Solana address validation requires full backend utilities"}}else{if(/^[0-9a-fA-F]{128}$/.test(s))return{isValid:!0,address:"Solana address validation requires full backend utilities"};if(/^[1-9A-HJ-NP-Za-km-z]{88}$/.test(s))return{isValid:!0,address:"Solana address validation requires full backend utilities"}}return{isValid:!1,address:""}}catch{return{isValid:!1,address:""}}},te=s=>{try{let a=s;return s.startsWith("0x")&&(a=s.slice(2)),/^[0-9a-fA-F]{64}$/.test(a)?{isValid:!0,address:"Sui address validation requires full backend utilities"}:{isValid:!1,address:""}}catch{return{isValid:!1,address:""}}},R={ACCOUNT_NAME_PREFIX:"Account"},he=({onNext:s})=>{const{chain:a,privateKey:t,setPrivateKey:r,accountName:i,setAccountName:y}=C(),[m,v]=g.useState(null),[b,p]=g.useState(null),{checkPrivateKeyExists:c}=T(),{accounts:u,initialized:S}=X();g.useEffect(()=>{!i&&S&&y(`${R.ACCOUNT_NAME_PREFIX} ${u.length>0?u.length+1:1}`)},[u,i,y,S]);const E=async()=>{if(!t)return!1;try{const h=V(t,a??null);if(!h.isValid)throw new Error("Invalid private key. Please try again.");p(h.address);try{if(await c(t))return v("This private key is already imported."),!1}catch{}return!0}catch{return v("Invalid private key. Please try again."),p(null),!1}};return e.jsxs("div",{className:"flex flex-col items-center justify-center size-full p-4",children:[e.jsxs("div",{className:"flex-1 size-full gap-4 space-y-2",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("h1",{className:"text-xl font-bold text-center",children:"Import private key"}),e.jsx("p",{className:"text-base text-gray-500 text-center",children:"Enter your private key to import the wallet"})]}),a!=null&&e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx(K,{placeholder:`Enter your ${a} private key`,value:t??"",showToggle:!1,onChange:async h=>{const N=h.target.value;if(r(N),v(null),N.trim()){const P=V(N,a??null);P.isValid?p(P.address):p(null)}else p(null)},onKeyDown:async h=>{h.key==="Enter"&&await E()&&s()}}),e.jsx("input",{type:"text",placeholder:`${R.ACCOUNT_NAME_PREFIX} ${u.length>0?u.length+1:1}`,value:i??"",onChange:h=>y(h.target.value),className:"w-full px-4 py-3 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color-light)] bg-[var(--card-color)] text-white placeholder-gray-400 text-base"}),m&&e.jsxs("div",{className:"text-red-500 mt-2 text-base flex items-center gap-1",children:[e.jsx(q,{}),m]}),b&&e.jsxs("div",{className:"text-green-500 mt-2 text-base flex items-center gap-1",children:[e.jsx(_,{}),e.jsx("span",{className:"text-sm break-all",children:b})]})]})]}),e.jsx("div",{className:"p-4 w-full",children:e.jsx(f,{onClick:async()=>{await E()&&s()},className:"w-full",disabled:!t||!a,children:"Continue"})})]})},re="/solana-sol-logo.png",ie="/sui-white-logo.png",fe=()=>{const{chain:s,setChain:a}=C();return e.jsx("div",{className:"flex flex-col items-center justify-center size-full p-4",children:e.jsxs("div",{className:"flex-1 size-full gap-4 space-y-2",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("h1",{className:"text-xl font-bold text-center",children:"Choose chain"}),e.jsxs("p",{className:"text-base text-gray-500 text-center",children:[s==null&&"Select the chain",s==="ethereum"&&"Enter your Ethereum private key",s==="solana"&&"Enter your Solana private key",s==="sui"&&"Enter your Sui private key",s==="hyperevm"&&"Enter your Hyperliquid private key",s==="base"&&"Enter your Base private key",s==="arbitrum"&&"Enter your Arbitrum private key"]})]}),s==null&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs(f,{onClick:()=>a("hyperevm"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:$,className:"size-6"})," Hyperliquid"]}),e.jsx(k,{className:"size-5"})]}),e.jsxs(f,{onClick:()=>a("ethereum"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:B,className:"size-6"})," Ethereum"]}),e.jsx(k,{className:"size-5"})]}),e.jsxs(f,{onClick:()=>a("base"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:Y,className:"size-6"})," Base"]}),e.jsx(k,{className:"size-5"})]}),e.jsxs(f,{onClick:()=>a("arbitrum"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:H,className:"size-6"})," Arbitrum"]}),e.jsx(k,{className:"size-5"})]}),e.jsxs(f,{onClick:()=>a("solana"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",disabled:!0,children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:re,className:"size-6"})," Solana"," ",e.jsx("span",{className:"text-xs text-gray-500",children:"(Coming Soon)"})]}),e.jsx(k,{className:"size-5"})]}),e.jsxs(f,{onClick:()=>a("sui"),className:"w-full bg-[var(--card-color)] text-[var(--primary-color-light)] hover:bg-[var(--card-color)]/80 justify-between py-4",disabled:!0,children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:ie,className:"size-6 object-contain"})," Sui",e.jsx("span",{className:"text-xs text-gray-500",children:"(Coming Soon)"})]}),e.jsx(k,{className:"size-5"})]})]})]})})};export{fe as C,xe as E,ue as I,de as K,me as S,pe as U,he as a,C as c};
